﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    Rigidbody2D rb;
    Animator anim;
    Gun gun;
    ParticleSystem blood;
    LevelManager gm;
    float gunScale;
    float gunPos;
    public int life;
    public bool left;
    public float stunTime;
    public float invulnerableTime;
    public bool invulnerable;
    public float knockback;
    public float speed;
    public float jumpForce;
    public float jumpGravFactor;
    //public float wallJumpScale;
    //public float wallJumpApplied;
    public bool grounded;
    public bool jump;
    //public bool wall;
    public float jumpForceApplied;
    public Color stunTint;
    public Color invulnerableTint;
    public GameObject cape;
    public LayerMask groundLayer;

	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        blood = GetComponent<ParticleSystem>();
        jumpForceApplied = 0;
        gun = GetComponent<Gun>();
        gunPos = gun.gunLoc.transform.localPosition.x;
        gunScale = gun.gunLoc.transform.localScale.x;
	}
	
	// Update is called once per frame
	void Update ()
    {
        grounded = isGrounded();
        if (grounded) anim.SetBool("grounded", true);
        else anim.SetBool("grounded", false);

        if (!grounded && !jump)
        {
            jumpForceApplied = 0;
            jump = true;
        }
        if (!grounded)
        {
            jumpForceApplied -= Time.deltaTime * jumpGravFactor;
        }

        if (Input.GetButtonDown("Jump") && grounded)
        {
            jumpForceApplied = jumpForce;
            grounded = false;
            anim.SetBool("grounded", grounded);
            jump = true;
        }
        else if (Input.GetButtonUp("Jump"))
        {
            jumpForceApplied /= 1.5f;
        }
        //wall jump logic
        /*if (Input.GetButtonDown("Jump") && wall)
        {
            wallJumpApplied *= wallJumpScale;
            rb.AddForce(new Vector2(wallJumpApplied,0), ForceMode2D.Impulse);
            wall = false;
            wallJumpApplied = 0;
        }*/
        if (left && Input.GetAxis("Horizontal") > 0)
        {
            left = false;
            GetComponent<SpriteRenderer>().flipX = false;
            //gun.gunLoc.flipX = false;
            gun.gunLoc.transform.localScale = new Vector2(gunScale, gun.gunLoc.transform.localScale.y);
            gun.gunLoc.transform.localPosition = new Vector2(gunPos, gun.gunLoc.transform.localPosition.y);
        }
        else if (!left && Input.GetAxis("Horizontal") < 0)
        {
            left = true;
            GetComponent<SpriteRenderer>().flipX = true;
            //gun.gunLoc.flipX = true;
            gun.gunLoc.transform.localScale = new Vector2(-gunScale, gun.gunLoc.transform.localScale.y);
            gun.gunLoc.transform.localPosition = new Vector2(-gunPos, gun.gunLoc.transform.localPosition.y);
        }


        //animation control
        if (Input.GetAxis("Horizontal") != 0 && grounded) anim.SetBool("walking", true);
        else anim.SetBool("walking", false);

        
	}

    private void FixedUpdate()
    {
        rb.velocity = new Vector2(Input.GetAxis("Horizontal") * Time.deltaTime * speed, jumpForceApplied);
    }

    private bool isGrounded()
    {
        RaycastHit2D hit = Physics2D.BoxCast(transform.position, new Vector2(.6f, .2f), 0, Vector2.down, 1f, groundLayer);
        return (hit.collider != null);

    }

    private void Hit(GameObject hitter)
    {
        //Hurt logic
        blood.Play(false);
        life--;
        rb.velocity = Vector2.zero;
        rb.AddForce((transform.position - hitter.transform.position).normalized * knockback, ForceMode2D.Impulse);
        if (life == 0) Die();
        else StartCoroutine("Stun");
    }

    private void Die()
    {
        rb.velocity = Vector2.zero;
        print("dead");
        anim.SetBool("hurt", true);
        anim.SetBool("dead", true);
        Destroy(gun.gunLoc.gameObject);
        Destroy(cape);
        this.enabled = false;
        gun.enabled = false;
        Invoke("EndGame", 2);
    }

    private void EndGame()
    {
        gm.EndGame();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Ground" && isGrounded()) jump = false;
        else if (collision.gameObject.tag == "Enemy" && !invulnerable) Hit(collision.gameObject);
        else if (collision.gameObject.tag == "WeaponPickup")
        {
            gun.ChangeGun(collision.gameObject.GetComponent<GunGiver>().gunIndex);
            Destroy(collision.gameObject);
        }
    }

    //private void OnCollisionStay2D(Collision2D collision)
    //{
        /*if (collision.gameObject.tag == "Ground")
        {
            grounded = false;
            ContactPoint2D[] contactPoints = new ContactPoint2D[5];
            collision.GetContacts(contactPoints);
            foreach (ContactPoint2D point in contactPoints)
            {
                if (point.normal == Vector2.up)
                {
                    grounded = true;
                    anim.SetBool("grounded", grounded);
                }
            }
        }*/
        //wall jump logic
        /*if (collision.gameObject.tag != "Enemy" && !wall)
        {
            ContactPoint2D[] contactPoints = new ContactPoint2D[30];
            int size = collision.GetContacts(contactPoints);
            foreach(ContactPoint2D point in contactPoints)
            {
                if (point.normal == Vector2.right)
                {
                    wallJumpApplied = 1;
                    wall = true;
                    jump = true;
                }
                else if(point.normal == Vector2.left)
                {
                    wallJumpApplied = -1;
                    wall = true;
                    jump = true;
                }
            }
        }*/
    //}

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Ground")
        {
            grounded = false;
            anim.SetBool("grounded", grounded);
        }
        //wall = false;
    }

    private IEnumerator Stun()
    {
        this.enabled = false;
        anim.SetBool("hurt", true);
        GetComponent<SpriteRenderer>().color = stunTint;
        yield return new WaitForSeconds(stunTime);
        this.enabled = true;
        anim.SetBool("hurt", false);
        GetComponent<SpriteRenderer>().color = invulnerableTint;
        invulnerable = true;
        yield return new WaitForSeconds(invulnerableTime);
        invulnerable = false;
        GetComponent<SpriteRenderer>().color = Color.white;
    }
}
