﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RangedEnemyScript : MonoBehaviour {

    public BulletScript bullet;

    bool isVisible = false;
    float shooterDelay;

	// Use this for initialization
	void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {
        float diff = Time.time - shooterDelay;
        if(isVisible && diff >= 2)
        { 
            Instantiate(bullet, new Vector3((transform.position.x - 0.6f), transform.position.y, transform.position.z), Quaternion.identity);
            shooterDelay = Time.time;
        }
	}

    private void OnBecameVisible()
    {
        shooterDelay = Time.time - 2;
        isVisible = true;
    }

    private void OnBecameInvisible()
    {
        isVisible = false;
    }
}
