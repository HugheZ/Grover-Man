﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelManager : MonoBehaviour {

    private LevelManager _instance = null;

    private int points;

    private void Awake()
    {
        if(_instance != null && _instance != this)
        {
            Destroy(this.gameObject);
            return;
        }
        _instance = this;
        DontDestroyOnLoad(gameObject);
    }

    void Start()
    {
        points = 0;
    }

    public void ResetForNextStage()
    {

    }

    public void HurtPlayer()
    {
        //TODO: update UI
    }

    public void GivePoints(int points)
    {
        this.points += points;
        //TODO: update UI
    }

    public void NextLevel()
    {
        //TODO: check level index and swap to next level
    }

    public void EndGame()
    {
        //TODO: reset to title screen and clear points
    }
	
	// Update is called once per frame
	void Update () {
		//TODO: if playable level, do nothing, else monitor printout of story on load screens
	}
}
