﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplosionController : MonoBehaviour {

    public float explosionTime;

    // Use this for initialization
    void Start () {
        Destroy(gameObject, explosionTime);
	}
}
