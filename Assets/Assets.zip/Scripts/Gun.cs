﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour {

    public ParticleSystem gunExplosion;
    public BulletScript baseBullet;
    public GameObject sniperBullet;
    public FingerGunBullet fgb;
    public int gunIndex;
    public float baseDistance;
    public float bulletHeight;
    public float cooldown;

    public List<Sprite> guns;

    public SpriteRenderer gunLoc;

    //gun based cooldown sets
    public float gun0Cooldown;
    public float gun1Cooldown;
    public float gun2Cooldown;
    public float gun3Cooldown;

	// Use this for initialization
	void Start () {
        gunLoc.sprite = guns[gunIndex];
	}
	
	// Update is called once per frame
	void Update () {
        if (cooldown > 0) cooldown -= Time.deltaTime;
        else if (cooldown < 0) cooldown = 0;
        if (Input.GetButtonDown("Fire")) Shoot(GetComponent<PlayerController>().left);
	}

    public void ChangeGun(int index)
    {
        if (index >= 0 && index <= guns.Count)
        {
            gunIndex = index;
            gunLoc.sprite = guns[index];
            cooldown = 0;
        }
    }

    private void Shoot(bool left)
    {
        if(gunIndex == 0)
        {
            ShootGun0(left);
        }
        //pistol
        else if(gunIndex == 1)
        {
            ShootGun1(left);
        }
        //sniper
        else if(gunIndex == 2)
        {
            ShootGun2(left);
        }
        else if(gunIndex == 3)
        {
            ShootGun3(left);
        }
    }

    //pistol
    private void ShootGun0(bool left)
    {
        if (cooldown <= 0)
        {
            if (!left)
            {
                Instantiate(baseBullet, transform.TransformPoint(new Vector3(baseDistance, bulletHeight, 0)), Quaternion.identity);
            }
            else Instantiate(baseBullet, transform.TransformPoint(new Vector3(-baseDistance, bulletHeight, 0)), Quaternion.Euler(0, 0, 180));
            cooldown = gun0Cooldown;
            gunExplosion.Play();
        }
    }

    //sniper
    private void ShootGun1(bool left)
    {
        if (cooldown <= 0)
        {
            if (!left) Instantiate(sniperBullet, transform.TransformPoint(new Vector3(baseDistance, bulletHeight, 0)), Quaternion.identity);
            else Instantiate(sniperBullet, transform.TransformPoint(new Vector3(-baseDistance, bulletHeight, 0)), Quaternion.Euler(0, 0, 180));
            cooldown = gun1Cooldown;
            gunExplosion.Play();
        }
    }

    //shotgun
    private void ShootGun2(bool left)
    {
        if(cooldown <= 0)
        {
            if (!left)
            {
                Instantiate(baseBullet, transform.TransformPoint(new Vector3(baseDistance, bulletHeight + .2f, 0)), Quaternion.Euler(0,0,10));
                Instantiate(baseBullet, transform.TransformPoint(new Vector3(baseDistance, bulletHeight, 0)), Quaternion.identity);
                Instantiate(baseBullet, transform.TransformPoint(new Vector3(baseDistance, bulletHeight - .2f, 0)), Quaternion.Euler(0,0,-10));
            }
            else
            {
                Instantiate(baseBullet, transform.TransformPoint(new Vector3(-baseDistance, bulletHeight - .2f, 0)), Quaternion.Euler(0, 0, 190));
                Instantiate(baseBullet, transform.TransformPoint(new Vector3(-baseDistance, bulletHeight, 0)), Quaternion.Euler(0, 0, 180));
                Instantiate(baseBullet, transform.TransformPoint(new Vector3(-baseDistance, bulletHeight + .2f, 0)), Quaternion.Euler(0, 0, 170));
            }
            cooldown = gun2Cooldown;
            gunExplosion.Play();
        }
    }

    private void ShootGun3(bool left)
    {
        if (cooldown <= 0)
        {
            if (!left)
            {
                Instantiate(fgb, transform.TransformPoint(new Vector3(baseDistance, bulletHeight, 0)), Quaternion.identity);
            }
            else Instantiate(fgb, transform.TransformPoint(new Vector3(-baseDistance, bulletHeight, 0)), Quaternion.Euler(0, 0, 180));
            cooldown = gun3Cooldown;
            gunExplosion.Play();
        }
    }
}
