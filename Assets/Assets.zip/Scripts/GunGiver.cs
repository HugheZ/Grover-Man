﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunGiver : MonoBehaviour {
    public int gunIndex;
    public float maxHeight;
    private float baseHeight;

    private void Start()
    {
        baseHeight = transform.position.y;
    }

    private void Update()
    {
        transform.position = new Vector2(transform.position.x, baseHeight + Height(Time.time));
    }

    private float Height(float y)
    {
        return Mathf.Sin(y) * maxHeight;
    }
}
