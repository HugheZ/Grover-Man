﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollower : MonoBehaviour {

    public PlayerController player;
    public Vector3 offset;
    public float deadDistance;
    public float moveSpeedFast;
    public float moveSpeedSlow;
    Vector3 velocity;

    // FixedUpdate is called when physics system moves
    //TODO: why does this produce less jitter than LateUpdate?!?
    void FixedUpdate()
    {
        if (player)
        {
            Vector3 newPos;
            float usedSpeed;
            Vector2 dirr = player.transform.position - transform.position;
            float distance = dirr.magnitude;
            if (distance > deadDistance)
            {
                newPos = player.transform.position + ((Vector3)dirr.normalized * deadDistance) + offset;
                usedSpeed = moveSpeedFast;
            }
            else
            {
                newPos = player.transform.position + offset;
                usedSpeed = moveSpeedSlow;
            }
            transform.position = Vector3.SmoothDamp(transform.position, newPos, ref velocity, usedSpeed);
        }
    }
}
